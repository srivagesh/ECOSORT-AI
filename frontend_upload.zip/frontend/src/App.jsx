
import { useState } from "react";
import EcoScene from "./EcoScene.jsx";
import ClosingSection from "./ClosingSection";
import {
  ArrowRight,
  BatteryCharging,
  CheckCircle2,
  Cpu,
  Leaf,
  Menu,
  Recycle,
  ScanSearch,
  ShieldCheck,
  Smartphone,
  UploadCloud,
  X,
  RotateCcw,
  Laptop,
} from "lucide-react";
import "./App.css";

const benefits = [
  {
    icon: ScanSearch,
    title: "AI-assisted identification",
    description:
      "Identify the likely category of an electronic item instead of guessing.",
  },
  {
    icon: Recycle,
    title: "Category-specific guidance",
    description:
      "Get practical recycling guidance tailored to the type of electronic waste.",
  },
  {
    icon: ShieldCheck,
    title: "Responsible handling",
    description:
      "Understand important safety precautions before handling electronic waste.",
  },
  {
    icon: RotateCcw,
    title: "Reuse before recycle",
    description:
      "Consider repair, refurbishment, or donation before recycling a working device.",
  },
];

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);

  const links = [
    ["Overview", "#overview"],
    ["How It Works", "#how-it-works"],
    ["Recycling Guide", "#recycling-guide"],
    // ["Drop-off", "#drop-off"],
  ];

  return (
    <header className="site-header">
      <a
        className="brand"
        href="#overview"
        onClick={() => setMenuOpen(false)}
        aria-label="EcoSort AI home"
      >
        <span className="brand-mark">
          <Leaf size={24} />
        </span>
        <span className="brand-copy">
          <strong>
            EcoSort <em>AI</em>
          </strong>
          <small>E-WASTE INTELLIGENCE</small>
        </span>
      </a>

      <button
        className="mobile-menu-toggle"
        onClick={() => setMenuOpen(!menuOpen)}
        aria-label={menuOpen ? "Close menu" : "Open menu"}
        aria-expanded={menuOpen}
      >
        {menuOpen ? <X size={23} /> : <Menu size={23} />}
      </button>

      <nav className={`nav-links ${menuOpen ? "nav-open" : ""}`}>
        {links.map(([label, href]) => (
          <a key={href} href={href} onClick={() => setMenuOpen(false)}>
            {label}
          </a>
        ))}
        <a
          className="nav-cta"
          href="#analyze"
          onClick={() => setMenuOpen(false)}
        >
          Analyze E-Waste <ArrowRight size={16} />
        </a>
      </nav>
    </header>
  );
}

function DeviceScene() {
  return (
    <div className="scene-frame">
      <div className="scene-label">
        <span className="live-dot" />
        LIVE 3D PREVIEW
      </div>

      <div className="scene-orbit orbit-one" />
      <div className="scene-orbit orbit-two" />

      <div className="globe">
        <div className="globe-grid" />
        <Leaf className="globe-leaf" size={52} />
      </div>

      <div className="scene-platform">
        <div className="platform-ring" />
      </div>

      <div className="floating-device device-phone">
        <Smartphone size={36} strokeWidth={1.5} />
      </div>

      <div className="floating-device device-laptop">
        <Laptop size={43} strokeWidth={1.4} />
      </div>

      <div className="floating-device device-battery">
        <BatteryCharging size={31} strokeWidth={1.5} />
      </div>

      <div className="floating-device device-chip">
        <Cpu size={29} strokeWidth={1.5} />
      </div>

      <div className="scene-float scene-float-top">
        <span className="float-icon">
          <ScanSearch size={18} />
        </span>
        <span>
          <b>SMART IDENTIFICATION</b>
          <small>Photo in, category out</small>
        </span>
      </div>

      <div className="scene-float scene-float-bottom">
        <span className="float-icon">
          <Leaf size={18} />
        </span>
        <span>
          <b>CIRCULAR ECONOMY</b>
          <small>Reuse before recycle</small>
        </span>
      </div>
    </div>
  );
}

function Hero() {
  return (
    <section className="hero section-shell" id="overview">
      <div className="hero-copy">
        <div className="eyebrow-pill">
          <span className="eyebrow-dot" />
          AI-POWERED E-WASTE SOLUTIONS
        </div>

        <h1>
          Give electronic waste a <span>smarter</span> second life.
        </h1>

        <p className="hero-description">
          Show EcoSort a photo of an old phone, laptop, charger or battery.
          It helps identify the likely category and guides you toward a safer,
          more responsible way to recycle it — before it ends up in a landfill.
        </p>

        <div className="hero-actions">
          <a className="button button-primary" href="#analyze">
            Analyze E-Waste <ArrowRight size={17} />
          </a>
          <a className="button button-secondary" href="#how-it-works">
            <ScanSearch size={17} /> Explore How It Works
          </a>
        </div>

        <div className="hero-meta">
          <span>NO SIGN-IN NEEDED</span>
          <i />
          <span>6 WASTE CATEGORIES</span>
          <i />
          <span>JPG · PNG · WEBP</span>
        </div>
      </div>

      <div className="hero-visual">
        <DeviceScene />
        <p className="scene-caption">
          {/* MOVE YOUR CURSOR ACROSS THE SCENE · HOVER A DEVICE TO INSPECT */}
        </p>
      </div>
    </section>
  );  
}

function Benefits() {
  return (
    <section className="benefits-section section-shell" id="how-it-works">
      <div className="benefits-heading">
        <div>
          <p className="section-eyebrow">WHAT THE PRODUCT IS BUILT TO DO</p>
          <h2>Practical help, kept honest about what it is.</h2>
        </div>
        <p className="honesty-note">
          These are intended benefits of EcoSort AI — not measured recycling
          outcomes, accuracy figures or certifications.
        </p>
      </div>

      <div className="benefits-grid">
        {benefits.map(({ icon: Icon, title, description }) => (
          <article className="benefit-card" key={title}>
            <span className="benefit-icon">
              <Icon size={21} strokeWidth={1.7} />
            </span>
            <h3>{title}</h3>
            <p>{description}</p>
          </article>
        ))}
      </div>
    </section>
  );
}

function AnalysisPreview() {
  const [fileName, setFileName] = useState("");

  return (
    <section className="analysis-section" id="analyze">
      <div className="section-shell">
        <div className="analysis-heading">
          <div>
            <p className="section-eyebrow">THE ANALYSIS WORKSPACE</p>
            <h2>Sort one item, right now.</h2>
            <p>
              Upload a photo of a single electronic item. The analyzer will
              eventually connect to a vision model to identify the item and
              recommend safe handling and recycling options.
            </p>
          </div>

          <div className="model-note">
            <ShieldCheck size={20} />
            <p>
              <strong>Designed with safety in mind</strong>
              <span>
                Model predictions can be wrong. Always confirm the item and
                follow appropriate safety guidance.
              </span>
            </p>
          </div>
        </div>

        <div className="analysis-grid">
          <article className="upload-card">
            <div className="card-topline">
              <div>
                <span className="step-label">STEP 1</span>
                <h3>Upload an item</h3>
              </div>
              <UploadCloud size={23} />
            </div>

            <p className="file-types">JPG, PNG OR WEBP · UP TO 12 MB</p>

            <label className="upload-dropzone">
              <span className="upload-icon">
                <UploadCloud size={30} />
              </span>
              <strong>
                {fileName || "Choose an image to get started"}
              </strong>
              <span>Browse for a photo on your device</span>
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={(event) =>
                  setFileName(event.target.files?.[0]?.name || "")
                }
              />
            </label>

            <p className="upload-tip">
              A clear photo of one device works best — phone, laptop,
              battery, charger or circuit board.
            </p>

            <button className="button button-primary analyze-button" disabled>
              Analyze image <ArrowRight size={17} />
            </button>
            <p className="phase-note">
              Image classification will be connected in Phase 3.
            </p>
          </article>

          <article className="result-card">
            <span className="step-label">STEP 2 · RESULT</span>
            <div className="result-empty">
              <span className="result-icon">
                <ScanSearch size={30} />
              </span>
              <h3>Your guidance will appear here</h3>
              <p>
                Once the vision model is connected, this area will display
                the predicted category and item-specific guidance.
              </p>
            </div>

            <div className="result-points">
              <p>
                <CheckCircle2 size={17} />
                Category predicted from the image
              </p>
              <p>
                <CheckCircle2 size={17} />
                Appropriate recycling route
              </p>
              <p>
                <CheckCircle2 size={17} />
                Safety precautions before handling
              </p>
            </div>
          </article>
        </div>
      </div>
    </section>
  );
}

function RecyclingGuide() {
  return (
    <section className="guide-section section-shell" id="recycling-guide">
      <p className="section-eyebrow">A BETTER ENDING FOR OLD ELECTRONICS</p>
      <h2>Don't throw it away. Give it a next step.</h2>
      <p>
        Repair what can be repaired, reuse what still works, and send
        unusable electronics to an appropriate collection or recycling service.
      </p>
      <a className="text-link" href="#analyze">
        Start with an item <ArrowRight size={17} />
      </a>
    </section>
  );
}

function Footer() {
  return (
    <footer className="site-footer">
      <a className="brand footer-brand" href="#overview">
        <span className="brand-mark">
          <Leaf size={22} />
        </span>
        <span className="brand-copy">
          <strong>
            EcoSort <em>AI</em>
          </strong>
          <small>E-WASTE INTELLIGENCE</small>
        </span>
      </a>
      <p>Smarter choices for a more circular future.</p>
      <a href="#overview">Back to top ↑</a>
    </footer>
  );
}


export default function App() {
return (
  <>
    <Header />

    <main>
      <Hero />
      <Benefits />
      <AnalysisPreview />
      <RecyclingGuide />
    </main>

    <ClosingSection />
  </>
);
}

